﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree
{
    public abstract class BinaryOperationBuilder: IOperationBuilder
    {
        protected IExpression paramLeft, paramRight;

        public void PushParameter(IExpression param)
        {
            if (paramLeft == null)
            {
                paramLeft = param;
            }
            else if (paramRight == null)
            {
                paramRight = param;
            }
            else
            {
                throw new InvalidOperationException();
            }
        }

        public bool IsEnoughParameters
        {
            get { return paramLeft != null && paramRight != null; }
        }

        public abstract IOperation Build();

        public abstract IOperationDefinition Definition { get; }
    }
}
