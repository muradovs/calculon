﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree
{
    public class SimpleExpression : IExpression
    {
        protected double Number { get; set; }

        public SimpleExpression(double number)
        {
            Number = number;
        }

        public double Result()
        {
            return Number;
        }
    }
}
