﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree
{
    public abstract class UnaryOperationBuilder: IOperationBuilder
    {
        protected IExpression Parameter;

        public void PushParameter(IExpression param)
        {
            if (Parameter == null)
            {
                Parameter = param;
            }
            else
            {
                throw new InvalidOperationException();
            }
        }

        public bool IsEnoughParameters
        {
            get { return Parameter != null; }
        }

        public abstract IOperation Build();

        public abstract IOperationDefinition Definition { get; }
    }
}
