﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StringToExpressionTree.Operations;

namespace StringToExpressionTree
{
    public class OperationPriorityComparer
    {
        private readonly IList<IOperationDefinition> priorityList;

        public OperationPriorityComparer(IList<IOperationDefinition> operationDefinitions)
        {
            priorityList = operationDefinitions;
        }

        public bool IsLess(IOperationDefinition param1, IOperationDefinition param2)
        {
            if (param1 == param2)
                return false;

            foreach (var def in priorityList)
            {
                if (def == param1)
                {
                    return false;
                }

                if (def == param2)
                {
                    return true;
                }
            }

            throw new InvalidOperationException();
        }

        public bool IsGreater(IOperationDefinition param1, IOperationDefinition param2)
        {
            if (param1 == param2)
                return false;

            return !IsLess(param1, param2);
        }
    }
}
