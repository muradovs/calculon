﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StringToExpressionTree.Operations;

namespace StringToExpressionTree
{
    class Program
    {
        static void Main(string[] args)
        {
            var expression = ExpressionParser.Parse("max(-0.1,max(-pi/6,cos(sqrt(16))))");

            Console.WriteLine(expression.Result());
            Console.WriteLine("Press any key...");
            Console.ReadKey();
        }
    }
}
