﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree
{
    public abstract class UnaryOperation : IOperation
    {
        public IExpression Parameter { get; protected set; }

        protected UnaryOperation(IExpression param)
        {
            Parameter = param;
        }

        #region IOperation Members

        public abstract IExpression Calculate();

        #endregion
    }
}
