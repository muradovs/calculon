﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree
{
    public abstract class BinaryOperation : IOperation
    {
        public IExpression Parameter1 { get; protected set; }

        public IExpression Parameter2 { get; protected set; }

        protected BinaryOperation(IExpression param1, IExpression param2)
        {
            Parameter1 = param1;
            Parameter2 = param2;
        }

        #region IOperation Members

        public abstract IExpression Calculate();

        #endregion
    }
}
