﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree
{
    public class CalculableExpression : IExpression
    {
        public CalculableExpression(IOperation operation)
        {
            Operation = operation;
        }

        public double Result()
        {
            return Operation.Calculate().Result();
        }

        protected IOperation Operation { get; set; }
    }
}
