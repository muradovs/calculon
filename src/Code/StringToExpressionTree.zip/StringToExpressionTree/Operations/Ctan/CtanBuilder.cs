﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class CtanBuilder : UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new CtanDefinition();

        public override IOperation Build()
        {
            return new Ctan(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
