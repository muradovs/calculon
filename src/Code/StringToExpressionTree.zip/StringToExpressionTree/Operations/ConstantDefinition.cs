﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public abstract class ConstantDefinition : IOperationDefinition
    {
        private static readonly int parameterCount = 0;
        private static readonly Associativity associativity = StringToExpressionTree.Associativity.Right;
        private static readonly OperationType type = OperationType.Constant;

        public int ParameterCount
        {
            get { return parameterCount; }
        }

        public Associativity Associativity
        {
            get { return associativity; }
        }

        public OperationType Type { get { return type; } }
    }
}
