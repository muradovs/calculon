﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class PiBuilder : IOperationBuilder
    {
        public static readonly IOperationDefinition definition = new PiDefinition();

        public void PushParameter(IExpression param)
        {
            throw new InvalidOperationException();
        }

        public bool IsEnoughParameters
        {
            get { return true; }
        }

        public IOperation Build()
        {
            return new Pi();
        }

        public IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
