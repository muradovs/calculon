﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public abstract class FunctionDefinition2 : FunctionDefinition
    {
        private static readonly int parameterCount = 2;

        public override int ParameterCount
        {
            get { return parameterCount; }
        }
    }
}
