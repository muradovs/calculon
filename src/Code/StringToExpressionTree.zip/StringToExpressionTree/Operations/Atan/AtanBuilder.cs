﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class AtanBuilder : UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new AtanDefinition();

        public override IOperation Build()
        {
            return new Atan(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
