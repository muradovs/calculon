﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class EBuilder: IOperationBuilder
    {
        public static readonly IOperationDefinition definition = new EDefinition();

        public void PushParameter(IExpression param)
        {
            throw new InvalidOperationException();
        }

        public bool IsEnoughParameters
        {
            get { return true; }
        }

        public IOperation Build()
        {
            return new E();
        }

        public IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
