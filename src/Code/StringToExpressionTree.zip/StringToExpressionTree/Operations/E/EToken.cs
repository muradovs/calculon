﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class EToken : IOperationToken
    {
        private static readonly string staticName = "e";

        public string Token
        {
            get { return staticName; }
        }

        public IOperationBuilder Create()
        {
            return new EBuilder();
        }
    }
}
