﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringToExpressionTree.Operations
{
    public sealed class PlusBuilder : BinaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new PlusDefinition();

        public override IOperation Build()
        {
            return new Plus(paramLeft, paramRight);
        }

        public override IOperationDefinition Definition { get { return definition; } }
    }
}
