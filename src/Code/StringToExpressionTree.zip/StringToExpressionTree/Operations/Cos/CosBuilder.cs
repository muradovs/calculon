﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class CosBuilder : UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new CosDefinition();

        public override IOperation Build()
        {
            return new Cos(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
