﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class SqrtBuilder: UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new SqrtDefinition();

        public override IOperation Build()
        {
            return new Sqrt(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
