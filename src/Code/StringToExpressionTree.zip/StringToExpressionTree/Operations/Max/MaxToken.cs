﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class MaxToken : IOperationToken
    {
        private static readonly string staticName = "max";

        public string Token
        {
            get { return staticName; }
        }

        public IOperationBuilder Create()
        {
            return new MaxBuilder();
        }
    }
}
