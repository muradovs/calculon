﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class MaxBuilder : BinaryOperationBuilder
    {
        public static readonly IOperationDefinition definition = new MaxDefinition();

        public override IOperation Build()
        {
            return new Max(paramLeft, paramRight);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
