﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class MinBuilder : BinaryOperationBuilder
    {
        public static readonly IOperationDefinition definition = new MinDefinition();

        public override IOperation Build()
        {
            return new Min(paramLeft, paramRight);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
