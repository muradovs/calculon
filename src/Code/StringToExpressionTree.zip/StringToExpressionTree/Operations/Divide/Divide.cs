﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class Divide: BinaryOperation
    {
        public Divide(IExpression param1, IExpression param2)
            : base(param1, param2)
        {

        }

        public override IExpression Calculate()
        {
            return new SimpleExpression(Parameter1.Result() / Parameter2.Result());
        }
    }
}
