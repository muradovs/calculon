﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringToExpressionTree.Operations
{
    public class DivideDefinition: IOperationDefinition
    {
        private static readonly int parameterCount = 2;
        private static readonly Associativity associativity = StringToExpressionTree.Associativity.Left;
        private static readonly OperationType type = OperationType.Operator;

        public int ParameterCount
        {
            get { return parameterCount; }
        }

        public Associativity Associativity
        {
            get { return associativity; }
        }

        public OperationType Type { get { return type; } }
    }
}
