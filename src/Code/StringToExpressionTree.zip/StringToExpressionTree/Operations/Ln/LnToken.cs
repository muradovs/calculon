﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class LnToken : IOperationToken
    {
        private static readonly string staticName = "ln";

        public string Token
        {
            get { return staticName; }
        }

        public IOperationBuilder Create()
        {
            return new LnBuilder();
        }
    }
}
