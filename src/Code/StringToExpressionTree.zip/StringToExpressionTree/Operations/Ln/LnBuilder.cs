﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class LnBuilder : UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new LnDefinition();

        public override IOperation Build()
        {
            return new Ln(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
