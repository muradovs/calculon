﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree
{
    public interface IOperationBuilder
    {
        void PushParameter(IExpression param);

        bool IsEnoughParameters { get; }

        IOperation Build();

        IOperationDefinition Definition { get; }
    }
}
