﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class Actan : UnaryOperation
    {
        public Actan(IExpression param)
            : base(param)
        {

        }

        public override IExpression Calculate()
        {
            return new SimpleExpression((System.Math.PI * 0.5) - System.Math.Atan(Parameter.Result()));
        }
    }
}
