﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class TanBuilder : UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new TanDefinition();

        public override IOperation Build()
        {
            return new Tan(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
