﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class MinusBuilder : BinaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new MinusDefinition();

        public override IOperation Build()
        {
            return new Minus(paramLeft, paramRight);
        }

        public override IOperationDefinition Definition { get { return definition; } }
    }
}
