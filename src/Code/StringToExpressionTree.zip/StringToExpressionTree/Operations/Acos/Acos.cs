﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class Acos : UnaryOperation
    {
        public Acos(IExpression param)
            : base(param)
        {

        }

        public override IExpression Calculate()
        {
            return new SimpleExpression(Math.Acos(Parameter.Result()));
        }
    }
}
