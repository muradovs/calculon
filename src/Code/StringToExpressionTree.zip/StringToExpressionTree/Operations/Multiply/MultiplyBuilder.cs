﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class MultiplyBuilder : BinaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new MultiplyDefinition();

        public override IOperation Build()
        {
            return new Multiply(paramLeft, paramRight);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
