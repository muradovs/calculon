﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class Multiply : BinaryOperation
    {
        public Multiply(IExpression param1, IExpression param2) :
            base(param1, param2)
        {

        }

        #region IOperation Members

        public override IExpression Calculate()
        {
            return new SimpleExpression(Parameter1.Result() * Parameter2.Result());
        }

        #endregion
    }
}
