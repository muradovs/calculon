﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class AsinBuilder : UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new AsinDefinition();

        public override IOperation Build()
        {
            return new Asin(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
