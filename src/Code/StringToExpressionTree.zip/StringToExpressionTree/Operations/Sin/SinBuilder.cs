﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class SinBuilder : UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new SinDefinition();

        public override IOperation Build()
        {
            return new Sin(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
