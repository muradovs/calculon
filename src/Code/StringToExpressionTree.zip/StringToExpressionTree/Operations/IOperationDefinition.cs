﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringToExpressionTree
{
    public interface IOperationDefinition
    {
        int ParameterCount { get; }
        Associativity Associativity { get; }
        OperationType Type { get; }
    }
}