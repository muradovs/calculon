﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public sealed class LgBuilder : UnaryOperationBuilder
    {
        private static readonly IOperationDefinition definition = new LgDefinition();

        public override IOperation Build()
        {
            return new Lg(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
