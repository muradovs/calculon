﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringToExpressionTree.Operations
{
    public class BracketsDefinition: IOperationDefinition
    {
        private static readonly int parameterCount = 1;
        private static readonly Associativity associativity = StringToExpressionTree.Associativity.Right;
        private static readonly OperationType type = OperationType.Agregator;

        public int ParameterCount
        {
            get { return parameterCount; }
        }

        public Associativity Associativity
        {
            get { return associativity; }
        }

        public OperationType Type { get { return type; } }
    }
}
