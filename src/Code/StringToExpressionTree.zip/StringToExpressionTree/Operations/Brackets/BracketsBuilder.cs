﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StringToExpressionTree.Operations;

namespace StringToExpressionTree.Operations
{
    public class BracketsBuilder : UnaryOperationBuilder
    {
        public static readonly IOperationDefinition definition = new BracketsDefinition();

        public override IOperation Build()
        {
            return new Brackets(Parameter);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
