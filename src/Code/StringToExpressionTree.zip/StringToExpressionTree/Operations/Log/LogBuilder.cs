﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public class LogBuilder : BinaryOperationBuilder
    {
        public static readonly IOperationDefinition definition = new LogDefinition();

        public override IOperation Build()
        {
            return new Log(paramLeft, paramRight);
        }

        public override IOperationDefinition Definition
        {
            get { return definition; }
        }
    }
}
