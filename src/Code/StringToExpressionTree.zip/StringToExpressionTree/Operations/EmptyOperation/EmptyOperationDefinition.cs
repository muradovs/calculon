﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringToExpressionTree.Operations
{
    public class EmptyOperationDefinition : IOperationDefinition
    {
        private static readonly int parameterCount = 1;
        private static readonly Associativity associativity = StringToExpressionTree.Associativity.Right;
        private static readonly OperationType type = OperationType.Operator;

        public int ParameterCount
        {
            get { return parameterCount; }
        }

        public Associativity Associativity
        {
            get { return associativity; }
        }

        public OperationType Type { get { return type; } }
    }
}
