﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree.Operations
{
    public abstract class FunctionDefinition1: FunctionDefinition
    {
        private static readonly int parameterCount = 1;

        public override int ParameterCount
        {
            get { return parameterCount; }
        }
    }
}
