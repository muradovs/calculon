﻿using StringToExpressionTree.Operations;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToExpressionTree
{
    public sealed class ExpressionParser
    {
        private static readonly IEnumerable<IOperationToken> preDefTokens = new List<IOperationToken>
            {
                new EToken(),
                new PiToken(),
                new SinToken(),
                new AsinToken(),
                new CosToken(),
                new AcosToken(),
                new TanToken(),
                new AtanToken(),
                new CtanToken(),
                new ActanToken(),
                new MaxToken(),
                new MinToken(),
                new SqrtToken(),
                new LogToken(),
                new LgToken(),
                new LnToken(),
                new AbsToken(),
                new AbsBracketsToken(),
                new BracketsToken(),
                new PowerToken(),
                new DivideToken(),
                new MultiplyToken(),
                new MinusToken(),
                new PlusToken()
            };
        /*
        IList<IOperationDefinition> priorityList = new List<IOperationDefinition>
    {
        new EBuilder().Definition,
        new PiBuilder().Definition,
        new SinBuilder().Definition,
        new AsinBuilder().Definition,
        new CosBuilder().Definition,
        new AcosBuilder().Definition,
        new TanBuilder().Definition,
        new AtanBuilder().Definition,
        new CtanBuilder().Definition,
        new ActanBuilder().Definition,
        new SqrtBuilder().Definition,
        new LgBuilder().Definition,
        new LnBuilder().Definition,
        new MaxBuilder().Definition,
        new MinBuilder().Definition,
        new LogBuilder().Definition,
        new AbsBracketsBuilder().Definition,
        new BracketsBuilder().Definition,
        new PowerBuilder().Definition,
        new DivideBuilder().Definition,
        new MultiplyBuilder().Definition,
        new MinusBuilder().Definition,
        new PlusBuilder().Definition
    };
        */

        public static IExpression Parse(string expression)
        {
            return new ExpressionParser(preDefTokens).ParseWithCustomTokens(expression);
        }

        private IEnumerable<IOperationToken> tokens;
        private OperationPriorityComparer comparer;

        public ExpressionParser(IEnumerable<IOperationToken> operationTokens)
        {
            tokens = operationTokens;

            var defs = new List<IOperationDefinition>();
            foreach (var token in tokens)
                defs.Add(token.Create().Definition);

            comparer = new OperationPriorityComparer(defs);
        }

        public IExpression ParseWithCustomTokens(string expression)
        {
            var stack = new ExpressionStack(comparer);

            for (int i = 0; i < expression.Length; )
            {
                if (char.IsDigit(expression[i]))
                {
                    var sb = new StringBuilder();
                    while (i < expression.Length && (char.IsDigit(expression[i]) || expression[i] == '.'))
                    {
                        sb.Append(expression[i]);
                        i++;
                    }

                    stack.Push(new SimpleExpression(Convert.ToDouble(sb.ToString(), CultureInfo.InvariantCulture)));
                }

                while (i < expression.Length && (expression[i] == ')' || expression[i] == '|'))
                {
                    if (stack.CompleteAgregate())
                        i++;
                    else
                        break;
                }

                if (i < expression.Length && expression[i] == ',')
                {
                    stack.CompleteAgregate();
                    i++;
                }

                // for functions and constants
                if (i < expression.Length && char.IsLetter(expression[i]))
                {
                    var tokenBuilder = new StringBuilder();
                    while (i < expression.Length && char.IsLetterOrDigit(expression[i]))
                    {
                        tokenBuilder.Append(expression[i]);
                        i++;
                    }

                    if (i < expression.Length && expression[i] == '(')
                    {
                        i++;
                    }

                    var t = tokenBuilder.ToString();
                    foreach (var token in tokens)
                    {
                        if (token.Token == t)
                        {
                            stack.Push(token.Create());
                            break;
                        }
                    }
                }

                // for operators and pure agregators
                {
                    var tokenBuilder = new StringBuilder();
                    bool isFound = false;
                    while (!isFound && i < expression.Length && !(char.IsDigit(expression[i]) || expression[i] == '.' || char.IsLetter(expression[i]) || expression[i] == ','))
                    {
                        tokenBuilder.Append(expression[i]);
                        var t = tokenBuilder.ToString();
                        foreach (var token in tokens)
                        {
                            if (token.Token == t)
                            {
                                stack.Push(token.Create());
                                isFound = true;
                                break;
                            }
                        }
                        i++;
                    }
                }
            }

            return stack.CreateExpression();
        }
    }
}
